package com.rekhta.nothingwidget;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.view.*; import android.widget.*; import org.json.*; import java.io.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24); root.setBackgroundColor(Color.rgb(8,8,8));
 TextView title=new TextView(this); title.setText("● REKHTA × NOTHING\nSHER LIBRARY"); title.setTextColor(Color.rgb(255,48,56)); title.setTextSize(20); title.setPadding(0,0,0,18); root.addView(title);
 TextView note=new TextView(this); note.setText("Browse the currently bundled starter collection. The full 1,500-sher directory still needs a verified, authorized data source."); note.setTextColor(Color.LTGRAY); note.setTextSize(13); root.addView(note);
 EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Search poet or sher"); search.setTextColor(Color.WHITE); search.setHintTextColor(Color.GRAY); root.addView(search);
 ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(1); sc.addView(list); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
 JSONArray data=load(); for(int i=0;i<data.length();i++){ JSONObject s=data.optJSONObject(i); if(s==null)continue; TextView row=new TextView(this); row.setText("\n"+s.optString("devanagari")+"\n"+s.optString("roman")+"\n— "+s.optString("poet")+"\n"+s.optString("category")+"\n"); row.setTextColor(Color.WHITE); row.setTextSize(15); row.setPadding(0,12,0,12); list.addView(row); View line=new View(this); line.setBackgroundColor(Color.DKGRAY); list.addView(line,new LinearLayout.LayoutParams(-1,1)); }
 search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence q,int st,int before,int count){String query=q.toString().toLowerCase(); for(int i=0;i<list.getChildCount();i+=2){View v=list.getChildAt(i); if(v instanceof TextView)v.setVisibility(((TextView)v).getText().toString().toLowerCase().contains(query)?View.VISIBLE:View.GONE);}} public void afterTextChanged(android.text.Editable e){}});
 }
 JSONArray load(){try(InputStream is=getAssets().open("poetry.json")){ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;while((n=is.read(buf))>0)b.write(buf,0,n);return new JSONArray(b.toString("UTF-8"));}catch(Exception e){return new JSONArray();}}
}
