package com.rekhta.nothingwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.time.*;
import java.util.*;

public class SherWidgetProvider extends AppWidgetProvider {
    static final String PREFS="rekhta_library_prefs";
    static final String NEXT="com.rekhta.nothinglibrary.NEXT";
    static final String REFRESH="com.rekhta.nothinglibrary.REFRESH";
    static final String OPEN_DIRECTORY="com.rekhta.nothinglibrary.DIRECTORY";

    @Override public void onEnabled(Context c) { scheduleNextNine(c); ensureDailySelection(c); }
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        ensureDailySelection(c); scheduleNextNine(c); for(int id:ids) render(c,m,id);
    }
    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c,i); if(c==null||i==null)return;
        if(NEXT.equals(i.getAction())) { SharedPreferences p=c.getSharedPreferences(PREFS,0); int idx=(p.getInt("index",0)+1)%5; p.edit().putInt("index",idx).apply(); updateAll(c); }
        else if(REFRESH.equals(i.getAction())) { selectDaily(c,true); scheduleNextNine(c); updateAll(c); }
        else if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) scheduleNextNine(c);
    }
    static void scheduleNextNine(Context c) {
        Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,9); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
        if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR,1);
        Intent in=new Intent(c,SherWidgetProvider.class); in.setAction(REFRESH);
        PendingIntent pi=PendingIntent.getBroadcast(c,902,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) { if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else am.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); }
    }
    static JSONArray load(Context c) {
        try(InputStream is=c.getAssets().open("poetry.json")) { ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n; while((n=is.read(buf))>0)b.write(buf,0,n); return new JSONArray(b.toString("UTF-8")); }
        catch(Exception e){return new JSONArray();}
    }
    static void ensureDailySelection(Context c) {
        SharedPreferences p=c.getSharedPreferences(PREFS,0); String today=LocalDate.now().toString();
        if(!today.equals(p.getString("day",""))) selectDaily(c,false);
    }
    static void selectDaily(Context c, boolean force) {
        SharedPreferences p=c.getSharedPreferences(PREFS,0); String today=LocalDate.now().toString();
        if(!force && today.equals(p.getString("day",""))) return;
        JSONArray all=load(c); ArrayList<Integer> ids=new ArrayList<>(); for(int i=0;i<all.length();i++) ids.add(i); Collections.shuffle(ids,new Random(System.nanoTime()+today.hashCode()));
        StringBuilder sb=new StringBuilder(); for(int i=0;i<Math.min(5,ids.size());i++){if(i>0)sb.append(',');sb.append(ids.get(i));}
        p.edit().putString("day",today).putString("daily_ids",sb.toString()).putInt("index",0).apply();
    }
    static JSONObject current(Context c) {
        SharedPreferences p=c.getSharedPreferences(PREFS,0); JSONArray all=load(c); String[] ids=p.getString("daily_ids","").split(",");
        int idx=Math.max(0,Math.min(p.getInt("index",0),Math.max(0,ids.length-1)));
        try { return all.getJSONObject(Integer.parseInt(ids[idx])); } catch(Exception e){return new JSONObject();}
    }
    static void updateAll(Context c) { AppWidgetManager m=AppWidgetManager.getInstance(c); int[] ids=m.getAppWidgetIds(new ComponentName(c,SherWidgetProvider.class)); for(int id:ids)render(c,m,id); }
    static void render(Context c,AppWidgetManager m,int id) {
        ensureDailySelection(c); JSONObject s=current(c); SharedPreferences p=c.getSharedPreferences(PREFS,0); String[] ids=p.getString("daily_ids","").split(","); int ix=p.getInt("index",0);
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_sher);
        v.setTextViewText(R.id.devanagari,s.optString("devanagari","आज का शेर जल्द आएगा"));
        v.setTextViewText(R.id.roman,s.optString("roman","Today's sher will appear here."));
        v.setTextViewText(R.id.poet,"— "+s.optString("poet",""));
        v.setTextViewText(R.id.count,String.format(Locale.ROOT,"%02d / %02d",Math.min(ix+1,5),Math.min(ids.length,5)));
        v.setTextViewText(R.id.source,"◫ OPEN SOURCE / DIRECTORY");
        Intent n=new Intent(c,SherWidgetProvider.class); n.setAction(NEXT); PendingIntent np=PendingIntent.getBroadcast(c,101,n,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.next,np); v.setOnClickPendingIntent(R.id.devanagari,np); v.setOnClickPendingIntent(R.id.roman,np);
        Intent open=new Intent(c,MainActivity.class); PendingIntent op=PendingIntent.getActivity(c,103,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.source,op);
        m.updateAppWidget(id,v);
    }
}
