# Rekhta × Nothing Library (starter Android project)

## What is implemented
- Native Android home-screen widget in monochrome/red styling.
- Tap the sher text or arrow to cycle through the five selected shers.
- Daily selection of five distinct entries from the bundled data, refreshed on a scheduled 9:00 AM local-time alarm (Android may delay background execution).
- A basic app screen that browses and searches the bundled poetry entries.
- JSON data schema for Urdu, Devanagari, Roman Urdu, poet, category, source URL and rights notes.

## Important data limitation
The bundled `poetry.json` contains only ten original illustrative demo entries. They are **not Rekhta poetry, not attributed to historical poets, and not the requested 1,500-sher directory**. This starter intentionally does not scrape Rekhta. Replace/add entries only from a source you are authorized to use. The target schema supports 150 poets × 10 shers once the directory is properly sourced and verified.

## Build
Open this folder as an Android Gradle project or use the included GitHub Actions workflow in the repository root after uploading the project contents. The project uses Android Gradle Plugin 8.6.1, Java 17 and compile SDK 35.
